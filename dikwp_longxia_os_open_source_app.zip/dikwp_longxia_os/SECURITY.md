# Security Policy

The offline core must not contain network clients, subprocess calls, dynamic code execution, hidden telemetry, credential collection, or host mutation helpers.
