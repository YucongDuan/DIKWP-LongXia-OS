# Code of Conduct

Use this project to improve clarity, evidence quality, and user agency. Do not use it to deceive, harass, surveil, or bypass legitimate restrictions.
