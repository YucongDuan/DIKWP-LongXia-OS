from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analyzer import load_json
from .reports import write_build_outputs, write_audit_outputs, write_json
from .static_audit import run_static_audit


def main() -> None:
    parser = argparse.ArgumentParser(prog="longxia", description="DIKWP LongXia OS CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_build = sub.add_parser("build", help="Build a semantic capsule and DeepSeek attachment prompt")
    p_build.add_argument("profile")
    p_build.add_argument("--out", default="outputs/demo")

    p_audit = sub.add_parser("audit", help="Audit an answer against a semantic capsule")
    p_audit.add_argument("answer")
    p_audit.add_argument("--capsule", required=True)
    p_audit.add_argument("--out", default="outputs/demo")

    p_static = sub.add_parser("static-audit", help="Run static boundary audit")
    p_static.add_argument("root")
    p_static.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")

    args = parser.parse_args()
    if args.cmd == "build":
        profile = load_json(args.profile)
        result = write_build_outputs(profile, args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.cmd == "audit":
        answer_text = Path(args.answer).read_text(encoding="utf-8")
        capsule = load_json(args.capsule)
        result = write_audit_outputs(answer_text, capsule, args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        result = run_static_audit(args.root)
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        write_json(out, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
