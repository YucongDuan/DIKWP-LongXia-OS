from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class DikwPRecord:
    data: List[str] = field(default_factory=list)
    information: List[str] = field(default_factory=list)
    knowledge: List[str] = field(default_factory=list)
    wisdom: List[str] = field(default_factory=list)
    purpose: Dict[str, Any] = field(default_factory=dict)
    reliability: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SemanticCapsule:
    capsule_id: str
    title: str
    user_profile: Dict[str, Any]
    task: Dict[str, Any]
    dikwp: DikwPRecord
    evidence_ledger: List[Dict[str, Any]]
    residual_queue: List[str]
    action_boundary: List[str]
    output_contract: Dict[str, Any]
    model_route_plan: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AuditResult:
    decision: str
    score: float
    issues: List[str]
    strengths: List[str]
    repair_actions: List[str]
    risk_categories: List[str]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
