from __future__ import annotations

from pathlib import Path
from typing import Dict, List

FORBIDDEN = [
    "import requests", "from requests", "import httpx", "from httpx", "import urllib",
    "import socket", "subprocess", "os.system", "eval(", "exec(", "compile(",
    "input(", "open('/etc", "open(\"/etc", "api_key", "secret_key", "password=",
]


def run_static_audit(root: str | Path) -> Dict[str, object]:
    root = Path(root)
    findings: List[Dict[str, object]] = []
    for path in root.rglob("*.py"):
        if path.name == "static_audit.py":
            continue
        text = path.read_text(encoding="utf-8")
        for idx, line in enumerate(text.splitlines(), start=1):
            lowered = line.lower()
            for token in FORBIDDEN:
                if token.lower() in lowered:
                    findings.append({"file": str(path), "line": idx, "token": token, "excerpt": line.strip()[:160]})
    return {
        "pass": not findings,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, credential capture, hidden telemetry, or host mutation helpers in the offline core.",
    }
