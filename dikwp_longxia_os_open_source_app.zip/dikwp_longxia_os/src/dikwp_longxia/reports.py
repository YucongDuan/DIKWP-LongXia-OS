from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from .analyzer import build_capsule, make_attachment_prompt, make_micro_capsule, audit_answer


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def write_build_outputs(profile: Dict[str, Any], out_dir: str | Path) -> Dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    capsule = build_capsule(profile)
    write_json(out / "semantic_capsule.json", capsule.to_dict())
    (out / "deepseek_attachment_prompt.md").write_text(make_attachment_prompt(capsule), encoding="utf-8")
    (out / "micro_capsule.txt").write_text(make_micro_capsule(capsule), encoding="utf-8")
    write_json(out / "model_route_plan.json", capsule.model_route_plan)
    summary = {
        "capsule_id": capsule.capsule_id,
        "title": capsule.title,
        "evidence_count": len(capsule.evidence_ledger),
        "budget_mode": capsule.model_route_plan.get("budget_mode"),
        "human_review_required": capsule.model_route_plan.get("human_review_required"),
        "boundary": capsule.action_boundary,
    }
    write_json(out / "longxia_build_summary.json", summary)
    return {"out_dir": str(out), **summary}


def write_audit_outputs(answer_text: str, capsule: Dict[str, Any], out_dir: str | Path) -> Dict[str, Any]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    result = audit_answer(answer_text, capsule)
    write_json(out / "answer_audit_report.json", result.to_dict())
    repair_md = "# DIKWP LongXia Answer Repair Plan\n\n"
    repair_md += f"Decision: **{result.decision}**\n\nScore: **{result.score}**\n\n"
    repair_md += "## Issues\n" + "\n".join(f"- {x}" for x in result.issues) + "\n\n"
    repair_md += "## Repair Actions\n" + "\n".join(f"- {x}" for x in result.repair_actions) + "\n\n"
    repair_md += "## Strengths\n" + "\n".join(f"- {x}" for x in result.strengths) + "\n"
    (out / "answer_repair_plan.md").write_text(repair_md, encoding="utf-8")
    return result.to_dict()
