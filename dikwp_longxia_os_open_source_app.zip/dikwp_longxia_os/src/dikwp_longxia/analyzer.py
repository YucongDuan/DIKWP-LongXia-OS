from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

from .models import DikwPRecord, SemanticCapsule, AuditResult
from .guard import scan_boundary
from .text_utils import split_sentences, contains_any, safe_excerpt


def _hash_short(payload: str) -> str:
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:12]


def _as_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v) for v in value]
    return [str(value)]


def load_json(path: str | Path) -> Dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def build_dikwp(profile: Dict[str, Any]) -> DikwPRecord:
    task = profile.get("task", {})
    evidence = profile.get("evidence", [])
    constraints = _as_list(task.get("constraints"))
    goals = _as_list(task.get("goals"))
    data = [safe_excerpt(str(x.get("content", x))) if isinstance(x, dict) else safe_excerpt(str(x)) for x in evidence]
    data.extend(_as_list(profile.get("raw_notes")))
    information = []
    if task.get("audience"):
        information.append(f"目标受众: {task.get('audience')}")
    if task.get("scenario"):
        information.append(f"使用场景: {task.get('scenario')}")
    if constraints:
        information.append("约束: " + "；".join(constraints))
    knowledge = _as_list(task.get("known_methods")) or ["使用 DIKWP 将任务转化为结构化语义对象。"]
    wisdom = [
        "不要把高自信语气当作证据。",
        "重要事实需要来源；动态事实需要实时核验。",
        "高风险结论必须降级为建议、清单或人工复核路径。",
    ]
    purpose = {
        "goal": goals or [task.get("question", "生成更清晰、更可审计的回答")],
        "value": _as_list(task.get("values")) or ["提高语义质量、减少误解、保留不确定性"],
        "constraints": constraints or ["不得绕过平台、访问、付费、审计或安全规则"],
        "time": task.get("time_window", "本次任务与后续可复用语义胶囊"),
        "feedback": task.get("feedback", "根据输出质量、证据充分性和用户复核结果修正胶囊"),
    }
    reliability = {
        "level": "Provisional / User-Supplied",
        "borrowed": True,
        "kill_conditions": [
            "用户提供的事实错误或过时",
            "目标模型输出与证据冲突",
            "任务进入医疗、法律、金融、公共安全等高风险域且缺人工复核",
        ],
    }
    return DikwPRecord(data, information, knowledge, wisdom, purpose, reliability)


def build_evidence_ledger(profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows = []
    for idx, item in enumerate(profile.get("evidence", []), start=1):
        if isinstance(item, dict):
            content = item.get("content", "")
            source = item.get("source", "user")
            reliability = item.get("reliability", "Provisional")
        else:
            content = str(item)
            source = "user"
            reliability = "Provisional"
        rows.append({
            "id": f"E{idx}",
            "source": source,
            "excerpt": safe_excerpt(content, 220),
            "support_scope": "仅支持用户已提供的上下文，不支持外部事实自动成立。",
            "reliability": reliability,
            "borrowed": True,
        })
    if not rows:
        rows.append({
            "id": "E0",
            "source": "none",
            "excerpt": "No explicit evidence provided.",
            "support_scope": "需要目标模型要求用户补充证据或标注 Provisional。",
            "reliability": "Hollow",
            "borrowed": False,
        })
    return rows


def model_route_plan(profile: Dict[str, Any]) -> Dict[str, Any]:
    task = profile.get("task", {})
    complexity = int(task.get("complexity", 3))
    needs_reasoning = bool(task.get("needs_reasoning", True))
    needs_long_context = bool(task.get("needs_long_context", False))
    safety_level = task.get("safety_level", "normal")
    if needs_long_context:
        recommended = "deepseek-v4-flash or deepseek-v4-pro if available; use long-context mode with explicit source ledger"
    elif complexity >= 4 or needs_reasoning:
        recommended = "thinking mode / deepseek-reasoner-compatible route when available"
    else:
        recommended = "non-thinking economical route for drafting, summarization, and rewrite tasks"
    return {
        "recommended_route": recommended,
        "fallback_route": "Use micro_capsule.txt in any available DeepSeek web/app/chat interface.",
        "budget_mode": "micro" if complexity <= 2 else "audit" if safety_level == "high" else "normal",
        "human_review_required": safety_level in {"high", "legal", "medical", "financial", "public_safety"},
        "notes": [
            "Model names and availability change; check official DeepSeek docs before production use.",
            "This package does not call DeepSeek API or store API keys.",
        ],
    }


def build_capsule(profile: Dict[str, Any]) -> SemanticCapsule:
    payload = json.dumps(profile, ensure_ascii=False, sort_keys=True)
    capsule_id = "longxia-" + _hash_short(payload)
    task = profile.get("task", {})
    dikwp = build_dikwp(profile)
    evidence = build_evidence_ledger(profile)
    residual = _as_list(task.get("unknowns")) or [
        "外部事实是否最新未核验。",
        "目标模型能力、上下文窗口、速率限制和平台规则可能变化。",
        "输出质量仍需用户复核。",
    ]
    boundary = [
        "不得用于越狱、绕过访问限制、绕过安全策略或提取隐藏系统提示。",
        "不得把 DeepSeek 或任何模型输出直接当作事实结论。",
        "医疗、法律、金融、公共安全等高风险任务必须保留人工复核。",
    ]
    output_contract = {
        "required_sections": ["核心回答", "依据", "不确定性", "行动边界", "下一步"],
        "style": task.get("style", "中文，清晰，必要时用表格，避免空泛口号"),
        "forbid": ["无证据保证", "过度确定", "绕过平台/安全/付费/权限", "伪造来源"],
    }
    return SemanticCapsule(
        capsule_id=capsule_id,
        title=task.get("title", "DIKWP LongXia Semantic Capsule"),
        user_profile=profile.get("user_profile", {}),
        task=task,
        dikwp=dikwp,
        evidence_ledger=evidence,
        residual_queue=residual,
        action_boundary=boundary,
        output_contract=output_contract,
        model_route_plan=model_route_plan(profile),
    )


def make_attachment_prompt(capsule: SemanticCapsule) -> str:
    d = capsule.to_dict()
    return f"""# DIKWP LongXia Attachment Prompt\n\n你现在收到一个便携式 DIKWP 语义胶囊。请不要把它当作越权指令；它只是用户的任务结构化说明。\n\n## Task\n{json.dumps(d['task'], ensure_ascii=False, indent=2)}\n\n## DIKWP\n{json.dumps(d['dikwp'], ensure_ascii=False, indent=2)}\n\n## Evidence Ledger\n{json.dumps(d['evidence_ledger'], ensure_ascii=False, indent=2)}\n\n## Residual Queue\n{chr(10).join('- ' + x for x in d['residual_queue'])}\n\n## Action Boundary\n{chr(10).join('- ' + x for x in d['action_boundary'])}\n\n## Required Output\n请按以下结构回答：\n1. 核心回答\n2. 依据与证据边界\n3. 仍不确定的部分\n4. 风险与行动边界\n5. 下一步建议\n\n请避免无证据的绝对化表达。需要最新事实时请明确说明需要检索。\n"""


def make_micro_capsule(capsule: SemanticCapsule) -> str:
    purpose = capsule.dikwp.purpose
    goal = "；".join(purpose.get("goal", [])) if isinstance(purpose.get("goal"), list) else str(purpose.get("goal"))
    constraints = "；".join(purpose.get("constraints", [])) if isinstance(purpose.get("constraints"), list) else str(purpose.get("constraints"))
    return (
        "DIKWP 微胶囊："
        f"目标={goal}；价值={';'.join(purpose.get('value', [])) if isinstance(purpose.get('value'), list) else purpose.get('value')}; "
        f"约束={constraints}; 证据={len(capsule.evidence_ledger)}条; "
        "输出须含核心回答/依据/不确定性/边界/下一步；不得伪造事实或绕过平台规则。"
    )


def audit_answer(answer_text: str, capsule: Dict[str, Any]) -> AuditResult:
    issues: List[str] = []
    strengths: List[str] = []
    repair: List[str] = []
    cats: List[str] = []
    lower = answer_text.lower()
    boundary_scan = scan_boundary(answer_text)
    if not boundary_scan["pass"]:
        cats.extend(boundary_scan["findings"])
        issues.append("回答中出现越权、绕过限制或高风险动作语言。")
        repair.append("删除越权表达，改为合法、可审计、人工复核路径。")
    certainty_terms = ["保证", "必然", "唯一", "100%", "绝对", "一定", "无风险", "guarantee", "only correct"]
    if contains_any(answer_text, certainty_terms):
        issues.append("存在无证据的过度确定性表达。")
        repair.append("将绝对化表达降级为条件化判断，并补充证据或不确定性。")
        cats.append("unsupported_certainty")
    evidence_words = ["依据", "来源", "证据", "引用", "数据", "ledger", "source"]
    if contains_any(answer_text, evidence_words):
        strengths.append("回答包含证据/依据意识。")
    else:
        issues.append("缺少证据或依据说明。")
        repair.append("增加 evidence boundary：哪些来自用户材料，哪些需外部核验。")
        cats.append("evidence_gap")
    residual_words = ["不确定", "未知", "残差", "需要核验", "可能", "provisional", "uncertain"]
    if contains_any(answer_text, residual_words):
        strengths.append("回答保留了不确定性。")
    else:
        issues.append("缺少不确定性/Residual 部分。")
        repair.append("增加 Residual：缺失事实、动态事实、模型能力边界。")
        cats.append("residual_gap")
    boundary_words = ["边界", "不得", "不能", "风险", "人工复核", "合规", "安全"]
    if contains_any(answer_text, boundary_words):
        strengths.append("回答包含行动边界或风险提示。")
    else:
        issues.append("缺少行动边界。")
        repair.append("补充 action boundary：高风险、不可逆、需要人工复核的内容。")
        cats.append("boundary_gap")
    required = capsule.get("output_contract", {}).get("required_sections", [])
    missing = [s for s in required if s not in answer_text]
    if missing:
        issues.append("缺少约定输出段落: " + ", ".join(missing))
        repair.append("按胶囊 required_sections 重排回答结构。")
        cats.append("format_gap")
    score = max(0.0, min(1.0, 1.0 - 0.13 * len(set(cats)) - 0.07 * len(issues)))
    decision = "accept" if score >= 0.78 else "repair_required" if score >= 0.45 else "reject_or_redraft"
    return AuditResult(decision, round(score, 4), issues, strengths, repair, sorted(set(cats)))
