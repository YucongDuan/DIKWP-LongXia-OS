from __future__ import annotations

import re
from typing import Iterable, List


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip())


def split_sentences(text: str) -> List[str]:
    raw = re.split(r"(?<=[。！？!?；;\.])\s*", text.strip())
    return [s.strip() for s in raw if s.strip()]


def contains_any(text: str, words: Iterable[str]) -> bool:
    lower = text.lower()
    return any(w.lower() in lower for w in words)


def safe_excerpt(text: str, limit: int = 160) -> str:
    text = normalize_text(text)
    return text if len(text) <= limit else text[: limit - 3] + "..."
