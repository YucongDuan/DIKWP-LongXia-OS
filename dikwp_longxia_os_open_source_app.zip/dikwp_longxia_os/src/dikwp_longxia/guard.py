from __future__ import annotations

from typing import Dict, List
from .text_utils import contains_any

BYPASS_TERMS = [
    "jailbreak", "越狱", "绕过", "规避", "bypass", "ignore previous",
    "系统提示词", "隐藏提示", "提取 system prompt", "破解", "盗号", "api key", "密钥",
    "免费获得付费", "绕过限制", "解除限制", "关闭审计", "disable audit",
]

SENSITIVE_HIGH_RISK = [
    "诊断", "开药", "法律结论", " guaranteed ", "100%", "稳赚", "无风险", "确保排名第一",
    "自动裁员", "自动判案", "自动下单", "控制硬件", "无人机起飞", "关闭安全",
]


def scan_boundary(text: str) -> Dict[str, object]:
    findings: List[str] = []
    if contains_any(text, BYPASS_TERMS):
        findings.append("access_bypass_or_jailbreak_language")
    if contains_any(text, SENSITIVE_HIGH_RISK):
        findings.append("high_risk_overclaim_or_action_language")
    return {
        "pass": not findings,
        "findings": findings,
        "boundary": "LongXia improves semantic clarity; it must not bypass model access, policy, credentials, or safety controls.",
    }
