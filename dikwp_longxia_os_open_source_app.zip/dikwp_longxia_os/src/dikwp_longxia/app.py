from __future__ import annotations

# Optional Streamlit UI. Import is intentionally local to keep offline core minimal.


def main() -> None:
    import streamlit as st  # type: ignore
    import json
    from .analyzer import build_capsule, make_attachment_prompt, make_micro_capsule

    st.title("DIKWP LongXia OS")
    st.caption("Portable semantic capsule for Chinese DeepSeek users")
    raw = st.text_area("Paste task profile JSON", height=300)
    if st.button("Build Capsule") and raw.strip():
        profile = json.loads(raw)
        capsule = build_capsule(profile)
        st.json(capsule.to_dict())
        st.subheader("Attachment Prompt")
        st.code(make_attachment_prompt(capsule))
        st.subheader("Micro Capsule")
        st.code(make_micro_capsule(capsule))
