# Contributing

Contributions are welcome if they preserve the project boundary: no jailbreaks, no access bypass, no hidden telemetry, no credential capture, and no policy evasion.
