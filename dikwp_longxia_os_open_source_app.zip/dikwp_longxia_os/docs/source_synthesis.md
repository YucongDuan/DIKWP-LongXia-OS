# Source Synthesis

This project is grounded in four themes:

1. DIKWP semantic transformation from data to purpose.
2. Semantic compression and intent alignment as efficiency measures.
3. Intent as a five-part structure: goal, value, constraints, time, feedback.
4. Audit boundaries: evidence, residual, kill/recovery, and action boundary.

It targets DeepSeek users because DeepSeek models are widely used by Chinese users and support chat, reasoning, and long-context workflows through official and ecosystem channels. The project keeps DeepSeek-specific integration as a prompt/template layer, not a hidden API client.
