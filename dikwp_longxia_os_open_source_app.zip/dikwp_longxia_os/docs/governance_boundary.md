# Governance Boundary

Allowed:

- semantic capsule generation;
- answer quality audit;
- output repair planning;
- low-token prompt compression;
- education and enterprise prompt standardization;
- evidence boundary and residual preservation.

Not allowed:

- DeepSeek jailbreaks;
- hidden system prompt extraction;
- access bypass;
- credential capture;
- paid plan evasion;
- rate-limit evasion;
- safety policy evasion;
- medical, legal, financial, public-safety automation without human review.

High-risk tasks must be converted into checklists, questions, preparation notes, or human-review workflows.
