# DeepSeek Integration Guide

## Supported usage modes

1. **Manual Web/App Mode**: copy `deepseek_attachment_prompt.md` or `micro_capsule.txt` into DeepSeek Chat.
2. **API Mode**: use the generated capsule as the message content in a compliant DeepSeek API call. This package does not include API code or store API keys.
3. **Training Mode**: use the semantic capsule as a classroom or enterprise prompt-writing template.

## Model route guidance

- For quick rewriting, summarization, and drafting, use a non-thinking economical model route.
- For planning, coding, legal-style reasoning, risk analysis, or governance design, use a thinking/reasoning route when available.
- For long enterprise materials, use a long-context route if available and keep source boundaries explicit.

## Prompt shape

The generated prompt forces five sections: core answer, evidence boundary, uncertainty, action boundary, and next step. This reduces overconfident one-shot answers.

## Boundary

Do not use this project to bypass DeepSeek policies, account access, paid plans, rate limits, or safety restrictions.
