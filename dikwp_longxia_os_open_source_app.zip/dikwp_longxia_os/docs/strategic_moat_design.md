# Strategic Moat Design

LongXia is intentionally open-source but should not give away all ecosystem value. The moat is not the capsule builder code alone. The moat is:

1. official DIKWP LongXia template registry;
2. TrustPassport certification for high-quality capsules;
3. Chinese scenario packs for education, SMEs, government service, active health, work transition, and legal help;
4. training certification for DIKWP Prompt Steward;
5. integration with ProofLedger, IntentGuard, AgentTrace, and MemoryLedger;
6. official benchmark for semantic compression and intent alignment.

The free repository attracts users. Official registries, templates, training, review reports, and enterprise deployments convert attention into reputation and revenue.
