# DIKWP Model Mapping

| DIKWP Layer | LongXia Implementation |
|---|---|
| D / Data | user task, notes, evidence excerpts, constraints |
| I / Information | scenario, audience, relations, risk boundaries |
| K / Knowledge | known methods, reusable templates, domain playbooks |
| W / Wisdom | values, risk tradeoffs, human review, high-risk boundaries |
| P / Purpose | goal, value, constraints, time, feedback |
| R / Reliability | evidence strength, residual, borrowed reliability, kill conditions |

LongXia uses this mapping to make DeepSeek prompts less vague and more resilient to output drift.
