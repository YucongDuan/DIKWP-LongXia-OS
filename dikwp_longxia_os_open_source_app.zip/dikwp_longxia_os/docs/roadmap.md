# Roadmap

## v0.1
Offline capsule builder and answer auditor.

## v0.2
Template registry format and capsule benchmark.

## v0.3
Integrations with ProofLedger, IntentGuard, and AgentTrace.

## v0.4
Browser extension for manual copy-paste workflows.

## v1.0
DIKWP LongXia TrustPassport certification and official template marketplace.
