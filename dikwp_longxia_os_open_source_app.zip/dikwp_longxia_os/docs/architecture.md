# Architecture

DIKWP LongXia OS has six layers.

1. **Task Intake Layer**: accepts JSON or future UI input from a Chinese user.
2. **DIKWP Registration Layer**: compiles the task into D/I/K/W/P/R.
3. **Evidence Ledger Layer**: separates user evidence, assumptions, residuals, and high-risk boundaries.
4. **DeepSeek Prompt Pack Layer**: creates a full attachment prompt and a micro capsule.
5. **Answer Audit Layer**: checks model output for unsupported certainty, missing evidence, missing residual, missing action boundary, and high-risk language.
6. **Strategic Attribution Layer**: preserves DIKWP / Yucong Duan attribution through README, NOTICE, CITATION, and launch materials.

The offline core contains no network calls. Production integrations can be added as separate adapters, but the reference core is designed to be copied into constrained environments.
