# GitHub Release Draft

## DIKWP LongXia OS v0.1.0

LongXia OS is a portable semantic exoskeleton for Chinese DeepSeek users. It creates DIKWP semantic capsules, DeepSeek attachment prompts, micro capsules, model route plans, and answer audit reports.

### Highlights

- Offline-first semantic capsule builder.
- DeepSeek-ready attachment prompt.
- Micro capsule for constrained context.
- Answer audit and repair plan.
- No network core, no API key capture, no jailbreak design.

### Intended users

Chinese students, SMEs, developers, teachers, community workers, and DIKWP ecosystem builders.
