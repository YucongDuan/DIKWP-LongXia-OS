from pathlib import Path
import json

from dikwp_longxia.analyzer import build_capsule, audit_answer, load_json
from dikwp_longxia.static_audit import run_static_audit


def test_build_capsule():
    profile = load_json(Path(__file__).parents[1] / "examples" / "sample_chinese_task.json")
    capsule = build_capsule(profile)
    assert capsule.capsule_id.startswith("longxia-")
    assert capsule.dikwp.purpose["goal"]
    assert len(capsule.evidence_ledger) >= 1


def test_audit_answer_flags_overconfidence():
    profile = load_json(Path(__file__).parents[1] / "examples" / "sample_chinese_task.json")
    capsule = build_capsule(profile).to_dict()
    answer = "100%保证成功，不需要证据，也不用人工复核。"
    result = audit_answer(answer, capsule)
    assert result.decision in {"repair_required", "reject_or_redraft"}
    assert "unsupported_certainty" in result.risk_categories


def test_static_audit_passes():
    root = Path(__file__).parents[1] / "src"
    result = run_static_audit(root)
    assert result["pass"] is True
