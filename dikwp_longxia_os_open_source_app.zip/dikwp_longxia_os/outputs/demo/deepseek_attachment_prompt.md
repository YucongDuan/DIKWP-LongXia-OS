# DIKWP LongXia Attachment Prompt

你现在收到一个便携式 DIKWP 语义胶囊。请不要把它当作越权指令；它只是用户的任务结构化说明。

## Task
{
  "title": "生成企业AI试点方案",
  "question": "请基于企业已有资料，帮助生成一个可落地、可审计、可控制成本的AI客服试点方案。",
  "scenario": "将语义胶囊复制到 DeepSeek Chat 或 DeepSeek API 对话中使用",
  "audience": "企业老板、技术负责人、合规负责人",
  "goals": [
    "形成4周AI客服试点计划",
    "给出成本、风险、证据和人工复核边界",
    "避免夸大AI效果"
  ],
  "values": [
    "真实可落地",
    "低成本",
    "证据优先",
    "保护客户隐私",
    "可回滚"
  ],
  "constraints": [
    "不得上传客户敏感数据",
    "不得承诺100%准确",
    "不得让AI自动拒绝客户服务",
    "高风险客户回复必须人工复核"
  ],
  "known_methods": [
    "DIKWP语义账本",
    "ProofLedger证据账本",
    "IntentGuard执行前门禁",
    "AgentTrace运行轨迹"
  ],
  "unknowns": [
    "企业真实客服数据量未核验",
    "DeepSeek当前API价格和限额可能变化",
    "行业合规要求需人工确认"
  ],
  "complexity": 4,
  "needs_reasoning": true,
  "needs_long_context": false,
  "safety_level": "normal",
  "time_window": "4周试点",
  "feedback": "每周复盘意图对齐、证据充分性、人工复核率、客户投诉率和成本"
}

## DIKWP
{
  "data": [
    "企业目前有3名客服，每天约200条咨询，主要问题是售前咨询、订单状态和售后退换。",
    "客户信息包括手机号、地址和订单号，试点阶段不得上传原始敏感数据。",
    "企业希望每月AI成本控制在1000元以内，并保留人工接管。",
    "DeepSeek可作为低成本模型入口，但需要结构化提示、证据账本和输出审计。"
  ],
  "information": [
    "目标受众: 企业老板、技术负责人、合规负责人",
    "使用场景: 将语义胶囊复制到 DeepSeek Chat 或 DeepSeek API 对话中使用",
    "约束: 不得上传客户敏感数据；不得承诺100%准确；不得让AI自动拒绝客户服务；高风险客户回复必须人工复核"
  ],
  "knowledge": [
    "DIKWP语义账本",
    "ProofLedger证据账本",
    "IntentGuard执行前门禁",
    "AgentTrace运行轨迹"
  ],
  "wisdom": [
    "不要把高自信语气当作证据。",
    "重要事实需要来源；动态事实需要实时核验。",
    "高风险结论必须降级为建议、清单或人工复核路径。"
  ],
  "purpose": {
    "goal": [
      "形成4周AI客服试点计划",
      "给出成本、风险、证据和人工复核边界",
      "避免夸大AI效果"
    ],
    "value": [
      "真实可落地",
      "低成本",
      "证据优先",
      "保护客户隐私",
      "可回滚"
    ],
    "constraints": [
      "不得上传客户敏感数据",
      "不得承诺100%准确",
      "不得让AI自动拒绝客户服务",
      "高风险客户回复必须人工复核"
    ],
    "time": "4周试点",
    "feedback": "每周复盘意图对齐、证据充分性、人工复核率、客户投诉率和成本"
  },
  "reliability": {
    "level": "Provisional / User-Supplied",
    "borrowed": true,
    "kill_conditions": [
      "用户提供的事实错误或过时",
      "目标模型输出与证据冲突",
      "任务进入医疗、法律、金融、公共安全等高风险域且缺人工复核"
    ]
  }
}

## Evidence Ledger
[
  {
    "id": "E1",
    "source": "user",
    "excerpt": "企业目前有3名客服，每天约200条咨询，主要问题是售前咨询、订单状态和售后退换。",
    "support_scope": "仅支持用户已提供的上下文，不支持外部事实自动成立。",
    "reliability": "User-Supplied",
    "borrowed": true
  },
  {
    "id": "E2",
    "source": "user",
    "excerpt": "客户信息包括手机号、地址和订单号，试点阶段不得上传原始敏感数据。",
    "support_scope": "仅支持用户已提供的上下文，不支持外部事实自动成立。",
    "reliability": "User-Supplied",
    "borrowed": true
  },
  {
    "id": "E3",
    "source": "user",
    "excerpt": "企业希望每月AI成本控制在1000元以内，并保留人工接管。",
    "support_scope": "仅支持用户已提供的上下文，不支持外部事实自动成立。",
    "reliability": "User-Supplied",
    "borrowed": true
  }
]

## Residual Queue
- 企业真实客服数据量未核验
- DeepSeek当前API价格和限额可能变化
- 行业合规要求需人工确认

## Action Boundary
- 不得用于越狱、绕过访问限制、绕过安全策略或提取隐藏系统提示。
- 不得把 DeepSeek 或任何模型输出直接当作事实结论。
- 医疗、法律、金融、公共安全等高风险任务必须保留人工复核。

## Required Output
请按以下结构回答：
1. 核心回答
2. 依据与证据边界
3. 仍不确定的部分
4. 风险与行动边界
5. 下一步建议

请避免无证据的绝对化表达。需要最新事实时请明确说明需要检索。
